import numpy as np
import random

class GeneticAlgorithm:
    def __init__(self, initial_gen_size, geneLength, selection_rate, mutation_rate):
        self.Population = [[np.random.randint(0, 2) for l in range(geneLength)] for i in range(initial_gen_size)]
        self.geneLength = geneLength
        self.selection_rate = selection_rate
        self.mutation_rate = mutation_rate

    def fitness(self, p):
        return sum(p)

    def selection(self):
        Selected = []
        maximum = sum([self.fitness(p) for p in self.Population])
        selection_probs = [self.fitness(p) / maximum for p in self.Population]
        for i in range(max(2, int(len(self.Population) * self.selection_rate))):
            selected = self.Population[np.random.choice(len(self.Population), p=selection_probs)]
            Selected.append(selected)
        return Selected

    def crossOver(self, Selected):
        def crossover(p1, p2):
            c1 = np.append(p1[:2], p2[2:])
            c2 = np.append(p2[:2], p1[2:])
            return c1, c2

        NewPopulation = []
        for i in range(len(Selected) // 2):
            p1 = Selected.pop()
            p2 = Selected.pop()
            NewPopulation.append(self.mutate(crossover(p1, p2)[0]))
            NewPopulation.append(self.mutate(crossover(p1, p2)[1]))
        return NewPopulation

    def mutate(self, p):
        for i in range(self.geneLength):
            if random.random() < self.mutation_rate:
                p[i] = abs(p[i] - 1)
        return p

    def Simulate(self, max_num_of_generation):
        generation_count = 0
        best_gene, best_fitness, purity = None, 0, 0

        while generation_count < max_num_of_generation:
            # Select parents
            Selected = self.selection()
            # Create new generation from parents
            NewPopulation = self.crossOver(Selected)
            self.Population = NewPopulation
            # check for best offspring
            total_fitness = 0
            for p in self.Population:
                if best_fitness < self.fitness(p):
                    best_fitness = self.fitness(p)
                    best_gene = p
                total_fitness += self.fitness(p)
            purity = total_fitness / (self.geneLength * len(self.Population))

            generation_count += 1
            print("{} | {} | {} | {}".format(generation_count, purity, best_gene, best_fitness))


""" Tujuannya menemukan gen paling sempurna yaitu [1, 1, 1, 1, 1, 1]. Satu semua. 
    Awalnya random [0, 1, 0, 0, 1] dibuat banyak jadi populasi awal, lalu disimulasikan.
    Setiap simulasi dipilih parent yang paling hebat, terus di cross over, dapet anak, terus anaknya di mutasi, 
    lalu jadi populasi baru.
    DIULANG TERUS """
GA = GeneticAlgorithm(100, 20, 1, 0.001)
GA.Simulate(500)
